Thank you for downloading the A.CRE Geocoding Excel Add-in!

This add-in was developed by the team at Adventures in CRE (A.CRE) to make auto-populating latitude and longitude in Excel easier and faster. The file is currently in beta, meaning it likely contains bugs. As bug reports and feature requests come in, we will release new versions of this tool.

For instructions on how to install and use the A.CRE Geocoding Excel Add-in, as well as how to get a Google Geocoding API key, visit: 

https://www.adventuresincre.com/instructions-geocode-excel-add-in/